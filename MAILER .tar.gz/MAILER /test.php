<?php 
include_once 'Mailer.php';
if($_POST){
    $postedData=$_POST;
    $message="<p>Name : {$postedData['myFirstName']} {$postedData['myLastName']}</p>"
    . "<p>Email Address : {$postedData['myEmail']}</p>"
    . "<p>Phone Number : {$postedData['myPhone']}</p>"
    . "<p><b>Message : </b> {$postedData['myInformation']}</p>";
    $emailSubject=$postedData['mySubject'];
    $mailerObj= new Mailer();
    $mailerObj->subject=$emailSubject;
    $mailerObj->message=$message;
    $mailerObj->replyTo=$postedData['myEmail'];
    if($mailerObj->FireMail()){
        header("location:{$postedData['_next']}");
    }
    
}

?>

<form action="#" class="form" id="gform" method="POST">
    <input name="_next" type="hidden" value="http://www.sitefuelusa.com/fueldelivery/">
    <div class="form-name">
        <div class="form-first">
            <label class="form-label" for="myFirstName">First Name</label>
            <input name="myFirstName" class="form-input form-input-fname" id="myFirstName" required="" style="cursor: auto; background-image: url(&quot;data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABAAAAAQCAYAAAAf8/9hAAABHklEQVQ4EaVTO26DQBD1ohQWaS2lg9JybZ+AK7hNwx2oIoVf4UPQ0Lj1FdKktevIpel8AKNUkDcWMxpgSaIEaTVv3sx7uztiTdu2s/98DywOw3Dued4Who/M2aIx5lZV1aEsy0+qiwHELyi+Ytl0PQ69SxAxkWIA4RMRTdNsKE59juMcuZd6xIAFeZ6fGCdJ8kY4y7KAuTRNGd7jyEBXsdOPE3a0QGPsniOnnYMO67LgSQN9T41F2QGrQRRFCwyzoIF2qyBuKKbcOgPXdVeY9rMWgNsjf9ccYesJhk3f5dYT1HX9gR0LLQR30TnjkUEcx2uIuS4RnI+aj6sJR0AM8AaumPaM/rRehyWhXqbFAA9kh3/8/NvHxAYGAsZ/il8IalkCLBfNVAAAAABJRU5ErkJggg==&quot;); background-attachment: scroll; background-size: 16px 18px; background-position: 98% 50%; background-repeat: no-repeat;"></div><div class="form-last">
            <label class="form-label" for="myLastName">Last Name</label>
            <input name="myLastName" class="form-input form-input-lname" id="myLastName" required="">
        </div>
    </div>
    <label class="form-label" for="myEmail">Email Address</label>
    <input name="myEmail" class="form-input" id="myEmail" required="" type="email">
    <label class="form-label" for="myPhone">Phone Number</label>
    <input name="myPhone" class="form-input form-phone form-phone1" required="" maxlength="10">
    <label class="form-label" for="mySubject">Subject</label>
    <input name="mySubject" class="form-input" id="mySubject">
    <label class="form-label" for="myInformation">Message</label>
    <textarea class="form-input" cols="20" id="myinformation" name="myInformation" required="" rows="5"></textarea>
    <input name="submit" class="submit" id="mySubmit" type="submit" value="Submit">
</form>